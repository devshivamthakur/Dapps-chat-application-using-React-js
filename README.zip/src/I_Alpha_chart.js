import React from 'react'

function I_Alpha_chart() {
  return (
    <div
    style={{
        width:"20%",
        borderWidth:2,
        borderStyle:"solid",
        borderColor:"#ababae"
    }}
    >

        <h3
        style={{
           textAlign:"left",
        }}
        >Net Changes</h3>

    </div>
  )
}

export default I_Alpha_chart