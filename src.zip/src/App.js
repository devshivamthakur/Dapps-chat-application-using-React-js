import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';

import Alpha_chart from './Alpha_chart';
import I_Alpha_chart from './I_Alpha_chart';

function App() {

  const [sampledata, setsampledata] = useState([
    {
      "subcategory": "Bookcases",
      "d__2021sale": 26426.8805,
      "d__2022sale": 30354.0737
    },
    {
      "subcategory": "Phones",
      "d__2021sale": 79178.01,
      "d__2022sale": 105668.392
    },
    {
      "subcategory": "Tables",
      "d__2021sale": 60835.4105,
      "d__2022sale": 60999.2025
    },
    {
      "subcategory": "Binders",
      "d__2021sale": 51580.133,
      "d__2022sale": 73627.451
    },
    {
      "subcategory": "Storage",
      "d__2021sale": 58845.676,
      "d__2022sale": 69819.25
    },
    {
      "subcategory": "Accessories",
      "d__2021sale": 41895.854,
      "d__2022sale": 59946.232
    },
    {
      "subcategory": "Art",
      "d__2021sale": 6119.766,
      "d__2022sale": 9009.96
    },
    {
      "subcategory": "Copiers",
      "d__2021sale": 49599.41,
      "d__2022sale": 62916.668
    },
    {
      "subcategory": "Furnishings",
      "d__2021sale": 28638.004,
      "d__2022sale": 29262.53
    },
    {
      "subcategory": "Paper",
      "d__2021sale": 20728.804,
      "d__2022sale": 28173.53
    },
    {
      "subcategory": "Envelopes",
      "d__2021sale": 4745.41,
      "d__2022sale": 3378.574
    },
    {
      "subcategory": "Chairs",
      "d__2021sale": 85079.431,
      "d__2022sale": 97721.633
    },
    {
      "subcategory": "Appliances",
      "d__2021sale": 26164.235,
      "d__2022sale": 43095.932
    },
    {
      "subcategory": "Labels",
      "d__2021sale": 2910.16,
      "d__2022sale": 3987.026
    },
    {
      "subcategory": "Fasteners",
      "d__2021sale": 1001.934,
      "d__2022sale": 6161.714
    },
    {
      "subcategory": "Machines",
      "d__2021sale": 55906.886,
      "d__2022sale": 43887.875
    },
    {
      "subcategory": "Supplies",
      "d__2021sale": 14277.576,
      "d__2022sale": 16075.66
    }
  ])
  const [graphData, setgraphData] = useState([])
  const [profit, setprofit] = useState(0)
  const [summaryData, setsummaryData] = useState({})
  function formatData(profitData) {
    return profitData.map((data) => ({
      label: data.subcategory,
      value: data.profit
    }));
  }
  function rearrange(sampledata) {
    let profit = 0;
    const profitData = sampledata.map((item) => {
      item.profit = item[`d__2022sale`] - item[`d__2021sale`];
      profit += item.profit;
      return item;
    });
  
    if (profit >= 0) { //if profit is positive //sort in descending order
      profitData.sort(function (x, y) {
        return y.profit - x.profit;
      });
    } else { //if profit is negative //sort in acending order
      profitData.sort(function (x, y) {
        return x.profit - y.profit;
      });
    }
    const multiplier = profit < 0 ? -1 : 1;
        var data = profitData.map((data) =>( multiplier * data.profit));
        let p_sum = 0;
        let l_sum = 0;
        for (var i = 0; i < data.length; ++i) {
          if (data[i] >= 0) {
            p_sum += data[i];
          
          } else {
            l_sum+= (data[i]);
          }
         
        }
        setsummaryData({
          profit: Number(p_sum).toFixed(2),
          loss: Number(l_sum).toFixed(2),
          net: Number(p_sum + l_sum).toFixed(2)
        })
    setprofit(profit)
    setgraphData(formatData(profitData))
  
  }
     
  useEffect(()=>{
    rearrange(sampledata)
  },[sampledata])


  return (
    <div className="App"  style={{
      padding: "20px",
    }}>
       <div className="main-container">
        <div className="graph-container">
        <Alpha_chart
      graphData={{profit: profit,wData: graphData}}
      />
        </div>
        <I_Alpha_chart
        {...summaryData}
        />
      </div>
      
     

      
    </div>
  );
}

export default App;
